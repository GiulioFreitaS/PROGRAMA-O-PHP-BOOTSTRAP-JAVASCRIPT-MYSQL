<?php
// Descobre o caminho base para funcionar em subpastas (salas/, horarios/, reservas/)
$base = (strpos($_SERVER['PHP_SELF'], '/salas/') !== false ||
         strpos($_SERVER['PHP_SELF'], '/horarios/') !== false ||
         strpos($_SERVER['PHP_SELF'], '/reservas/') !== false) ? '../' : '';
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Espaço de Co-working | Reserva de Salas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="<?= $base ?>assets/css/style.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
  <div class="container">
    <a class="navbar-brand fw-bold" href="<?= $base ?>index.php"><i class="bi bi-building"></i> Co-working Reservas</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navMenu">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="<?= $base ?>index.php"><i class="bi bi-house-door"></i> Início</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= $base ?>salas/listar.php"><i class="bi bi-door-open"></i> Salas</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= $base ?>horarios/listar.php"><i class="bi bi-clock"></i> Horários</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= $base ?>reservas/listar.php"><i class="bi bi-calendar-check"></i> Reservas</a></li>
      </ul>
    </div>
  </div>
</nav>
<div class="container mb-5">
