<?php
require_once '../config/database.php';
$pdo = getConnection();
$reservas = $pdo->query("
    SELECT r.*, s.nome AS sala_nome
    FROM reservas r
    JOIN salas s ON s.id = r.sala_id
    ORDER BY r.data_reserva DESC, r.hora_inicio DESC
")->fetchAll();
include '../includes_header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="fw-bold"><i class="bi bi-calendar-check"></i> Reservas</h3>
    <a href="criar.php" class="btn btn-warning"><i class="bi bi-plus-lg"></i> Nova Reserva</a>
</div>

<?php if (isset($_GET['msg'])): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?= htmlspecialchars($_GET['msg']) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="card card-stat p-3">
<div class="table-responsive">
<table class="table table-hover align-middle mb-0">
    <thead>
        <tr>
            <th>#</th>
            <th>Sala</th>
            <th>Responsável</th>
            <th>Data</th>
            <th>Horário</th>
            <th>Status</th>
            <th class="text-end">Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php if (count($reservas) === 0): ?>
        <tr><td colspan="7" class="text-center text-muted py-4">Nenhuma reserva cadastrada.</td></tr>
        <?php endif; ?>
        <?php foreach ($reservas as $r): ?>
        <tr>
            <td><?= $r['id'] ?></td>
            <td><?= htmlspecialchars($r['sala_nome']) ?></td>
            <td><?= htmlspecialchars($r['nome_responsavel']) ?></td>
            <td><?= date('d/m/Y', strtotime($r['data_reserva'])) ?></td>
            <td><?= substr($r['hora_inicio'],0,5) ?> - <?= substr($r['hora_fim'],0,5) ?></td>
            <td><span class="badge badge-<?= $r['status'] ?>"><?= ucfirst($r['status']) ?></span></td>
            <td class="text-end">
                <a href="editar.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></a>
                <a href="excluir.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-danger btn-excluir" data-msg="Excluir esta reserva?"><i class="bi bi-trash"></i></a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
</div>
</div>

<?php include '../includes_footer.php'; ?>
