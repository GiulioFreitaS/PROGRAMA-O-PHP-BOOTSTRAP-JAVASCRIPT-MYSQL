<?php
require_once '../config/database.php';
$pdo = getConnection();
$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("DELETE FROM reservas WHERE id = ?");
$stmt->execute([$id]);

header("Location: listar.php?msg=Reserva excluída com sucesso!");
exit;
