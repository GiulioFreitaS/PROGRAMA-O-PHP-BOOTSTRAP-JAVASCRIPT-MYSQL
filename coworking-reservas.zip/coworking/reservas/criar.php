<?php
require_once '../config/database.php';
$pdo = getConnection();
$salas = $pdo->query("SELECT id, nome FROM salas WHERE status='ativa' ORDER BY nome")->fetchAll();
$erro = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sala_id = (int)($_POST['sala_id'] ?? 0);
    $nome_responsavel = trim($_POST['nome_responsavel'] ?? '');
    $email_responsavel = trim($_POST['email_responsavel'] ?? '');
    $data_reserva = $_POST['data_reserva'] ?? '';
    $hora_inicio = $_POST['hora_inicio'] ?? '';
    $hora_fim = $_POST['hora_fim'] ?? '';
    $observacoes = trim($_POST['observacoes'] ?? '');

    if (!$sala_id || !$nome_responsavel || !$data_reserva || !$hora_inicio || !$hora_fim) {
        $erro = "Preencha todos os campos obrigatórios.";
    } elseif ($hora_fim <= $hora_inicio) {
        $erro = "O horário final deve ser depois do horário inicial.";
    } else {
        // Verifica conflito de horário na mesma sala/data
        $stmtCheck = $pdo->prepare("
            SELECT COUNT(*) FROM reservas
            WHERE sala_id = ? AND data_reserva = ? AND status = 'confirmada'
            AND (hora_inicio < ? AND hora_fim > ?)
        ");
        $stmtCheck->execute([$sala_id, $data_reserva, $hora_fim, $hora_inicio]);
        $conflito = $stmtCheck->fetchColumn();

        if ($conflito > 0) {
            $erro = "Já existe uma reserva confirmada para esta sala nesse dia e horário.";
        } else {
            $stmt = $pdo->prepare("INSERT INTO reservas (sala_id, nome_responsavel, email_responsavel, data_reserva, hora_inicio, hora_fim, observacoes) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$sala_id, $nome_responsavel, $email_responsavel, $data_reserva, $hora_inicio, $hora_fim, $observacoes]);
            header("Location: listar.php?msg=Reserva criada com sucesso!");
            exit;
        }
    }
}

include '../includes_header.php';
?>

<h3 class="fw-bold mb-3"><i class="bi bi-plus-lg"></i> Nova Reserva</h3>

<?php if ($erro): ?>
<div class="alert alert-danger"><?= htmlspecialchars($erro) ?></div>
<?php endif; ?>

<?php if (count($salas) === 0): ?>
<div class="alert alert-warning">Cadastre pelo menos uma sala ativa antes de criar reservas. <a href="../salas/criar.php">Criar sala</a></div>
<?php else: ?>

<div class="card card-stat p-4">
<form method="POST" class="needs-validation" novalidate>
    <div class="mb-3">
        <label class="form-label">Sala *</label>
        <select name="sala_id" class="form-select" required>
            <option value="">Selecione...</option>
            <?php foreach ($salas as $s): ?>
                <option value="<?= $s['id'] ?>" <?= (isset($_POST['sala_id']) && $_POST['sala_id']==$s['id'])?'selected':'' ?>><?= htmlspecialchars($s['nome']) ?></option>
            <?php endforeach; ?>
        </select>
        <div class="invalid-feedback">Selecione uma sala.</div>
    </div>
    <div class="row">
        <div class="col-md-6 mb-3">
            <label class="form-label">Nome do responsável *</label>
            <input type="text" name="nome_responsavel" class="form-control" required value="<?= htmlspecialchars($_POST['nome_responsavel'] ?? '') ?>">
            <div class="invalid-feedback">Informe o nome do responsável.</div>
        </div>
        <div class="col-md-6 mb-3">
            <label class="form-label">E-mail</label>
            <input type="email" name="email_responsavel" class="form-control" value="<?= htmlspecialchars($_POST['email_responsavel'] ?? '') ?>">
        </div>
    </div>
    <div class="row">
        <div class="col-md-4 mb-3">
            <label class="form-label">Data *</label>
            <input type="date" name="data_reserva" class="form-control" required value="<?= htmlspecialchars($_POST['data_reserva'] ?? '') ?>">
            <div class="invalid-feedback">Informe a data.</div>
        </div>
        <div class="col-md-4 mb-3">
            <label class="form-label">Hora início *</label>
            <input type="time" name="hora_inicio" id="hora_inicio" class="form-control" required value="<?= htmlspecialchars($_POST['hora_inicio'] ?? '') ?>">
            <div class="invalid-feedback">Informe o horário inicial.</div>
        </div>
        <div class="col-md-4 mb-3">
            <label class="form-label">Hora fim *</label>
            <input type="time" name="hora_fim" id="hora_fim" class="form-control" required value="<?= htmlspecialchars($_POST['hora_fim'] ?? '') ?>">
            <div class="invalid-feedback">Informe um horário final válido.</div>
        </div>
    </div>
    <div class="mb-3">
        <label class="form-label">Observações</label>
        <textarea name="observacoes" class="form-control" rows="3"><?= htmlspecialchars($_POST['observacoes'] ?? '') ?></textarea>
    </div>
    <button type="submit" class="btn btn-warning"><i class="bi bi-check-lg"></i> Salvar</button>
    <a href="listar.php" class="btn btn-secondary">Cancelar</a>
</form>
</div>
<?php endif; ?>

<?php include '../includes_footer.php'; ?>
