<?php
require_once '../config/database.php';
$pdo = getConnection();
$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM reservas WHERE id = ?");
$stmt->execute([$id]);
$reserva = $stmt->fetch();

if (!$reserva) {
    header("Location: listar.php?msg=Reserva não encontrada.");
    exit;
}

$salas = $pdo->query("SELECT id, nome FROM salas ORDER BY nome")->fetchAll();
$erro = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sala_id = (int)($_POST['sala_id'] ?? 0);
    $nome_responsavel = trim($_POST['nome_responsavel'] ?? '');
    $email_responsavel = trim($_POST['email_responsavel'] ?? '');
    $data_reserva = $_POST['data_reserva'] ?? '';
    $hora_inicio = $_POST['hora_inicio'] ?? '';
    $hora_fim = $_POST['hora_fim'] ?? '';
    $observacoes = trim($_POST['observacoes'] ?? '');
    $status = $_POST['status'] ?? 'confirmada';

    if (!$sala_id || !$nome_responsavel || !$data_reserva || !$hora_inicio || !$hora_fim) {
        $erro = "Preencha todos os campos obrigatórios.";
    } elseif ($hora_fim <= $hora_inicio) {
        $erro = "O horário final deve ser depois do horário inicial.";
    } else {
        $stmtCheck = $pdo->prepare("
            SELECT COUNT(*) FROM reservas
            WHERE sala_id = ? AND data_reserva = ? AND status = 'confirmada' AND id != ?
            AND (hora_inicio < ? AND hora_fim > ?)
        ");
        $stmtCheck->execute([$sala_id, $data_reserva, $id, $hora_fim, $hora_inicio]);
        $conflito = $stmtCheck->fetchColumn();

        if ($conflito > 0 && $status === 'confirmada') {
            $erro = "Já existe uma reserva confirmada para esta sala nesse dia e horário.";
        } else {
            $stmt = $pdo->prepare("UPDATE reservas SET sala_id=?, nome_responsavel=?, email_responsavel=?, data_reserva=?, hora_inicio=?, hora_fim=?, observacoes=?, status=? WHERE id=?");
            $stmt->execute([$sala_id, $nome_responsavel, $email_responsavel, $data_reserva, $hora_inicio, $hora_fim, $observacoes, $status, $id]);
            header("Location: listar.php?msg=Reserva atualizada com sucesso!");
            exit;
        }
    }
    $reserva = array_merge($reserva, $_POST);
}

include '../includes_header.php';
?>

<h3 class="fw-bold mb-3"><i class="bi bi-pencil"></i> Editar Reserva</h3>

<?php if ($erro): ?>
<div class="alert alert-danger"><?= htmlspecialchars($erro) ?></div>
<?php endif; ?>

<div class="card card-stat p-4">
<form method="POST" class="needs-validation" novalidate>
    <div class="mb-3">
        <label class="form-label">Sala *</label>
        <select name="sala_id" class="form-select" required>
            <?php foreach ($salas as $s): ?>
                <option value="<?= $s['id'] ?>" <?= ($reserva['sala_id']==$s['id'])?'selected':'' ?>><?= htmlspecialchars($s['nome']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="row">
        <div class="col-md-6 mb-3">
            <label class="form-label">Nome do responsável *</label>
            <input type="text" name="nome_responsavel" class="form-control" required value="<?= htmlspecialchars($reserva['nome_responsavel']) ?>">
        </div>
        <div class="col-md-6 mb-3">
            <label class="form-label">E-mail</label>
            <input type="email" name="email_responsavel" class="form-control" value="<?= htmlspecialchars($reserva['email_responsavel']) ?>">
        </div>
    </div>
    <div class="row">
        <div class="col-md-3 mb-3">
            <label class="form-label">Data *</label>
            <input type="date" name="data_reserva" class="form-control" required value="<?= htmlspecialchars($reserva['data_reserva']) ?>">
        </div>
        <div class="col-md-3 mb-3">
            <label class="form-label">Hora início *</label>
            <input type="time" name="hora_inicio" id="hora_inicio" class="form-control" required value="<?= substr($reserva['hora_inicio'],0,5) ?>">
        </div>
        <div class="col-md-3 mb-3">
            <label class="form-label">Hora fim *</label>
            <input type="time" name="hora_fim" id="hora_fim" class="form-control" required value="<?= substr($reserva['hora_fim'],0,5) ?>">
        </div>
        <div class="col-md-3 mb-3">
            <label class="form-label">Status</label>
            <select name="status" class="form-select">
                <option value="confirmada" <?= $reserva['status']=='confirmada'?'selected':'' ?>>Confirmada</option>
                <option value="cancelada" <?= $reserva['status']=='cancelada'?'selected':'' ?>>Cancelada</option>
            </select>
        </div>
    </div>
    <div class="mb-3">
        <label class="form-label">Observações</label>
        <textarea name="observacoes" class="form-control" rows="3"><?= htmlspecialchars($reserva['observacoes']) ?></textarea>
    </div>
    <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg"></i> Atualizar</button>
    <a href="listar.php" class="btn btn-secondary">Cancelar</a>
</form>
</div>

<?php include '../includes_footer.php'; ?>
