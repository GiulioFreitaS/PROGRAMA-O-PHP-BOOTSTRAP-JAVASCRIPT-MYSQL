-- =========================================================
-- Espaço de Co-working (Reserva de Salas)
-- Banco de Dados MySQL
-- =========================================================

CREATE DATABASE IF NOT EXISTS coworking_db
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE coworking_db;

-- ---------------------------------------------------------
-- Tabela: salas
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS salas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao TEXT,
    capacidade INT NOT NULL,
    localizacao VARCHAR(150),
    status ENUM('ativa','inativa') NOT NULL DEFAULT 'ativa',
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Tabela: horarios_disponiveis
-- Horários que cada sala fica disponível em cada dia da semana
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS horarios_disponiveis (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sala_id INT NOT NULL,
    dia_semana ENUM('Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo') NOT NULL,
    hora_inicio TIME NOT NULL,
    hora_fim TIME NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sala_id) REFERENCES salas(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Tabela: reservas
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS reservas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sala_id INT NOT NULL,
    nome_responsavel VARCHAR(150) NOT NULL,
    email_responsavel VARCHAR(150),
    data_reserva DATE NOT NULL,
    hora_inicio TIME NOT NULL,
    hora_fim TIME NOT NULL,
    observacoes TEXT,
    status ENUM('confirmada','cancelada') NOT NULL DEFAULT 'confirmada',
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sala_id) REFERENCES salas(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Dados de exemplo
-- ---------------------------------------------------------
INSERT INTO salas (nome, descricao, capacidade, localizacao, status) VALUES
('Sala Aurora', 'Sala de reunião com TV e quadro branco', 8, '1º Andar - Bloco A', 'ativa'),
('Sala Nimbus', 'Sala compacta ideal para calls e entrevistas', 4, '1º Andar - Bloco B', 'ativa'),
('Sala Horizonte', 'Sala ampla para workshops e treinamentos', 20, '2º Andar - Bloco A', 'ativa');

INSERT INTO horarios_disponiveis (sala_id, dia_semana, hora_inicio, hora_fim) VALUES
(1, 'Segunda', '08:00:00', '18:00:00'),
(1, 'Terça',   '08:00:00', '18:00:00'),
(2, 'Segunda', '09:00:00', '17:00:00'),
(3, 'Quarta',  '08:00:00', '20:00:00');

INSERT INTO reservas (sala_id, nome_responsavel, email_responsavel, data_reserva, hora_inicio, hora_fim, observacoes) VALUES
(1, 'Giulio Pimentel', 'giulio@example.com', '2026-09-25', '10:00:00', '11:00:00', 'Reunião de alinhamento de projeto');
