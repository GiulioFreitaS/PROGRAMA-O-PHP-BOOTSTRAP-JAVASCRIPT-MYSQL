<?php
require_once '../config/database.php';
$pdo = getConnection();
$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM horarios_disponiveis WHERE id = ?");
$stmt->execute([$id]);
$horario = $stmt->fetch();

if (!$horario) {
    header("Location: listar.php?msg=Horário não encontrado.");
    exit;
}

$salas = $pdo->query("SELECT id, nome FROM salas ORDER BY nome")->fetchAll();
$erro = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sala_id = (int)($_POST['sala_id'] ?? 0);
    $dia_semana = $_POST['dia_semana'] ?? '';
    $hora_inicio = $_POST['hora_inicio'] ?? '';
    $hora_fim = $_POST['hora_fim'] ?? '';

    if (!$sala_id || !$dia_semana || !$hora_inicio || !$hora_fim) {
        $erro = "Preencha todos os campos.";
    } elseif ($hora_fim <= $hora_inicio) {
        $erro = "O horário final deve ser depois do horário inicial.";
    } else {
        $stmt = $pdo->prepare("UPDATE horarios_disponiveis SET sala_id=?, dia_semana=?, hora_inicio=?, hora_fim=? WHERE id=?");
        $stmt->execute([$sala_id, $dia_semana, $hora_inicio, $hora_fim, $id]);
        header("Location: listar.php?msg=Horário atualizado com sucesso!");
        exit;
    }
    $horario = array_merge($horario, $_POST);
}

include '../includes_header.php';

$dias = ['Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'];
?>

<h3 class="fw-bold mb-3"><i class="bi bi-pencil"></i> Editar Horário</h3>

<?php if ($erro): ?>
<div class="alert alert-danger"><?= htmlspecialchars($erro) ?></div>
<?php endif; ?>

<div class="card card-stat p-4">
<form method="POST" class="needs-validation" novalidate>
    <div class="mb-3">
        <label class="form-label">Sala *</label>
        <select name="sala_id" class="form-select" required>
            <?php foreach ($salas as $s): ?>
                <option value="<?= $s['id'] ?>" <?= ($horario['sala_id']==$s['id'])?'selected':'' ?>><?= htmlspecialchars($s['nome']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="mb-3">
        <label class="form-label">Dia da semana *</label>
        <select name="dia_semana" class="form-select" required>
            <?php foreach ($dias as $d): ?>
                <option value="<?= $d ?>" <?= ($horario['dia_semana']==$d)?'selected':'' ?>><?= $d ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="row">
        <div class="col-md-6 mb-3">
            <label class="form-label">Hora início *</label>
            <input type="time" name="hora_inicio" id="hora_inicio" class="form-control" required value="<?= substr($horario['hora_inicio'],0,5) ?>">
        </div>
        <div class="col-md-6 mb-3">
            <label class="form-label">Hora fim *</label>
            <input type="time" name="hora_fim" id="hora_fim" class="form-control" required value="<?= substr($horario['hora_fim'],0,5) ?>">
        </div>
    </div>
    <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg"></i> Atualizar</button>
    <a href="listar.php" class="btn btn-secondary">Cancelar</a>
</form>
</div>

<?php include '../includes_footer.php'; ?>
