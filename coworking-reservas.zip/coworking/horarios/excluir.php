<?php
require_once '../config/database.php';
$pdo = getConnection();
$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("DELETE FROM horarios_disponiveis WHERE id = ?");
$stmt->execute([$id]);

header("Location: listar.php?msg=Horário excluído com sucesso!");
exit;
