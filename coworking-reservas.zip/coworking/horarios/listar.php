<?php
require_once '../config/database.php';
$pdo = getConnection();
$horarios = $pdo->query("
    SELECT h.*, s.nome AS sala_nome
    FROM horarios_disponiveis h
    JOIN salas s ON s.id = h.sala_id
    ORDER BY s.nome, FIELD(h.dia_semana,'Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'), h.hora_inicio
")->fetchAll();
include '../includes_header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="fw-bold"><i class="bi bi-clock"></i> Horários Disponíveis</h3>
    <a href="criar.php" class="btn btn-success"><i class="bi bi-plus-lg"></i> Novo Horário</a>
</div>

<?php if (isset($_GET['msg'])): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?= htmlspecialchars($_GET['msg']) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="card card-stat p-3">
<div class="table-responsive">
<table class="table table-hover align-middle mb-0">
    <thead>
        <tr>
            <th>#</th>
            <th>Sala</th>
            <th>Dia da semana</th>
            <th>Início</th>
            <th>Fim</th>
            <th class="text-end">Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php if (count($horarios) === 0): ?>
        <tr><td colspan="6" class="text-center text-muted py-4">Nenhum horário cadastrado.</td></tr>
        <?php endif; ?>
        <?php foreach ($horarios as $h): ?>
        <tr>
            <td><?= $h['id'] ?></td>
            <td><?= htmlspecialchars($h['sala_nome']) ?></td>
            <td><?= $h['dia_semana'] ?></td>
            <td><?= substr($h['hora_inicio'],0,5) ?></td>
            <td><?= substr($h['hora_fim'],0,5) ?></td>
            <td class="text-end">
                <a href="editar.php?id=<?= $h['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></a>
                <a href="excluir.php?id=<?= $h['id'] ?>" class="btn btn-sm btn-outline-danger btn-excluir" data-msg="Excluir este horário?"><i class="bi bi-trash"></i></a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
</div>
</div>

<?php include '../includes_footer.php'; ?>
