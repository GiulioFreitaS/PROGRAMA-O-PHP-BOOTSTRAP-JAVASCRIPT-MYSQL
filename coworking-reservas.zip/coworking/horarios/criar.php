<?php
require_once '../config/database.php';
$pdo = getConnection();
$salas = $pdo->query("SELECT id, nome FROM salas WHERE status='ativa' ORDER BY nome")->fetchAll();
$erro = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sala_id = (int)($_POST['sala_id'] ?? 0);
    $dia_semana = $_POST['dia_semana'] ?? '';
    $hora_inicio = $_POST['hora_inicio'] ?? '';
    $hora_fim = $_POST['hora_fim'] ?? '';

    if (!$sala_id || !$dia_semana || !$hora_inicio || !$hora_fim) {
        $erro = "Preencha todos os campos.";
    } elseif ($hora_fim <= $hora_inicio) {
        $erro = "O horário final deve ser depois do horário inicial.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO horarios_disponiveis (sala_id, dia_semana, hora_inicio, hora_fim) VALUES (?, ?, ?, ?)");
        $stmt->execute([$sala_id, $dia_semana, $hora_inicio, $hora_fim]);
        header("Location: listar.php?msg=Horário criado com sucesso!");
        exit;
    }
}

include '../includes_header.php';

$dias = ['Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'];
?>

<h3 class="fw-bold mb-3"><i class="bi bi-plus-lg"></i> Novo Horário</h3>

<?php if ($erro): ?>
<div class="alert alert-danger"><?= htmlspecialchars($erro) ?></div>
<?php endif; ?>

<?php if (count($salas) === 0): ?>
<div class="alert alert-warning">Cadastre pelo menos uma sala ativa antes de criar horários. <a href="../salas/criar.php">Criar sala</a></div>
<?php else: ?>

<div class="card card-stat p-4">
<form method="POST" class="needs-validation" novalidate>
    <div class="mb-3">
        <label class="form-label">Sala *</label>
        <select name="sala_id" class="form-select" required>
            <option value="">Selecione...</option>
            <?php foreach ($salas as $s): ?>
                <option value="<?= $s['id'] ?>" <?= (isset($_POST['sala_id']) && $_POST['sala_id']==$s['id'])?'selected':'' ?>><?= htmlspecialchars($s['nome']) ?></option>
            <?php endforeach; ?>
        </select>
        <div class="invalid-feedback">Selecione uma sala.</div>
    </div>
    <div class="mb-3">
        <label class="form-label">Dia da semana *</label>
        <select name="dia_semana" class="form-select" required>
            <option value="">Selecione...</option>
            <?php foreach ($dias as $d): ?>
                <option value="<?= $d ?>" <?= (isset($_POST['dia_semana']) && $_POST['dia_semana']==$d)?'selected':'' ?>><?= $d ?></option>
            <?php endforeach; ?>
        </select>
        <div class="invalid-feedback">Selecione um dia da semana.</div>
    </div>
    <div class="row">
        <div class="col-md-6 mb-3">
            <label class="form-label">Hora início *</label>
            <input type="time" name="hora_inicio" id="hora_inicio" class="form-control" required value="<?= htmlspecialchars($_POST['hora_inicio'] ?? '') ?>">
            <div class="invalid-feedback">Informe o horário inicial.</div>
        </div>
        <div class="col-md-6 mb-3">
            <label class="form-label">Hora fim *</label>
            <input type="time" name="hora_fim" id="hora_fim" class="form-control" required value="<?= htmlspecialchars($_POST['hora_fim'] ?? '') ?>">
            <div class="invalid-feedback">Informe um horário final válido (depois do início).</div>
        </div>
    </div>
    <button type="submit" class="btn btn-success"><i class="bi bi-check-lg"></i> Salvar</button>
    <a href="listar.php" class="btn btn-secondary">Cancelar</a>
</form>
</div>
<?php endif; ?>

<?php include '../includes_footer.php'; ?>
