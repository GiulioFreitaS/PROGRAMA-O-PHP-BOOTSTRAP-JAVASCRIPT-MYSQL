// Validação client-side dos formulários (Bootstrap) + confirmação de exclusão
(function () {
  'use strict';

  // Ativa validação do Bootstrap em todos os forms com a classe needs-validation
  const forms = document.querySelectorAll('.needs-validation');
  Array.from(forms).forEach((form) => {
    form.addEventListener('submit', (event) => {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
      }
      form.classList.add('was-validated');
    }, false);
  });

  // Confirmação antes de excluir qualquer registro
  document.querySelectorAll('.btn-excluir').forEach((btn) => {
    btn.addEventListener('click', function (e) {
      const msg = this.getAttribute('data-msg') || 'Tem certeza que deseja excluir este registro?';
      if (!confirm(msg)) {
        e.preventDefault();
      }
    });
  });

  // Validação simples: hora_fim deve ser maior que hora_inicio
  const horaInicio = document.getElementById('hora_inicio');
  const horaFim = document.getElementById('hora_fim');
  if (horaInicio && horaFim) {
    const validarHoras = () => {
      if (horaInicio.value && horaFim.value && horaFim.value <= horaInicio.value) {
        horaFim.setCustomValidity('O horário final deve ser depois do horário inicial.');
      } else {
        horaFim.setCustomValidity('');
      }
    };
    horaInicio.addEventListener('change', validarHoras);
    horaFim.addEventListener('change', validarHoras);
  }
})();
