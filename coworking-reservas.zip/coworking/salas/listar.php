<?php
require_once '../config/database.php';
$pdo = getConnection();
$salas = $pdo->query("SELECT * FROM salas ORDER BY id DESC")->fetchAll();
include '../includes_header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="fw-bold"><i class="bi bi-door-open"></i> Salas</h3>
    <a href="criar.php" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Nova Sala</a>
</div>

<?php if (isset($_GET['msg'])): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?= htmlspecialchars($_GET['msg']) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="card card-stat p-3">
<div class="table-responsive">
<table class="table table-hover align-middle mb-0">
    <thead>
        <tr>
            <th>#</th>
            <th>Nome</th>
            <th>Capacidade</th>
            <th>Localização</th>
            <th>Status</th>
            <th class="text-end">Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php if (count($salas) === 0): ?>
        <tr><td colspan="6" class="text-center text-muted py-4">Nenhuma sala cadastrada.</td></tr>
        <?php endif; ?>
        <?php foreach ($salas as $s): ?>
        <tr>
            <td><?= $s['id'] ?></td>
            <td><?= htmlspecialchars($s['nome']) ?></td>
            <td><i class="bi bi-people"></i> <?= $s['capacidade'] ?> pessoas</td>
            <td><?= htmlspecialchars($s['localizacao']) ?></td>
            <td><span class="badge badge-<?= $s['status'] ?>"><?= ucfirst($s['status']) ?></span></td>
            <td class="text-end">
                <a href="visualizar.php?id=<?= $s['id'] ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-eye"></i></a>
                <a href="editar.php?id=<?= $s['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></a>
                <a href="excluir.php?id=<?= $s['id'] ?>" class="btn btn-sm btn-outline-danger btn-excluir" data-msg="Excluir a sala '<?= htmlspecialchars($s['nome']) ?>'? Isso também removerá horários e reservas vinculados."><i class="bi bi-trash"></i></a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
</div>
</div>

<?php include '../includes_footer.php'; ?>
