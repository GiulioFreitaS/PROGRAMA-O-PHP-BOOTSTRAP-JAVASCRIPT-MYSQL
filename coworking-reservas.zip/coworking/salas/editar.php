<?php
require_once '../config/database.php';
$pdo = getConnection();
$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM salas WHERE id = ?");
$stmt->execute([$id]);
$sala = $stmt->fetch();

if (!$sala) {
    header("Location: listar.php?msg=Sala não encontrada.");
    exit;
}

$erro = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $descricao = trim($_POST['descricao'] ?? '');
    $capacidade = (int)($_POST['capacidade'] ?? 0);
    $localizacao = trim($_POST['localizacao'] ?? '');
    $status = $_POST['status'] ?? 'ativa';

    if ($nome === '' || $capacidade <= 0) {
        $erro = "Preencha o nome e uma capacidade válida.";
    } else {
        $stmt = $pdo->prepare("UPDATE salas SET nome=?, descricao=?, capacidade=?, localizacao=?, status=? WHERE id=?");
        $stmt->execute([$nome, $descricao, $capacidade, $localizacao, $status, $id]);
        header("Location: listar.php?msg=Sala atualizada com sucesso!");
        exit;
    }
    $sala = array_merge($sala, $_POST);
}

include '../includes_header.php';
?>

<h3 class="fw-bold mb-3"><i class="bi bi-pencil"></i> Editar Sala</h3>

<?php if ($erro): ?>
<div class="alert alert-danger"><?= htmlspecialchars($erro) ?></div>
<?php endif; ?>

<div class="card card-stat p-4">
<form method="POST" class="needs-validation" novalidate>
    <div class="mb-3">
        <label class="form-label">Nome da sala *</label>
        <input type="text" name="nome" class="form-control" required value="<?= htmlspecialchars($sala['nome']) ?>">
        <div class="invalid-feedback">Informe o nome da sala.</div>
    </div>
    <div class="mb-3">
        <label class="form-label">Descrição</label>
        <textarea name="descricao" class="form-control" rows="3"><?= htmlspecialchars($sala['descricao']) ?></textarea>
    </div>
    <div class="row">
        <div class="col-md-4 mb-3">
            <label class="form-label">Capacidade (pessoas) *</label>
            <input type="number" name="capacidade" class="form-control" min="1" required value="<?= htmlspecialchars($sala['capacidade']) ?>">
            <div class="invalid-feedback">Informe uma capacidade válida.</div>
        </div>
        <div class="col-md-4 mb-3">
            <label class="form-label">Localização</label>
            <input type="text" name="localizacao" class="form-control" value="<?= htmlspecialchars($sala['localizacao']) ?>">
        </div>
        <div class="col-md-4 mb-3">
            <label class="form-label">Status</label>
            <select name="status" class="form-select">
                <option value="ativa" <?= $sala['status']=='ativa'?'selected':'' ?>>Ativa</option>
                <option value="inativa" <?= $sala['status']=='inativa'?'selected':'' ?>>Inativa</option>
            </select>
        </div>
    </div>
    <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg"></i> Atualizar</button>
    <a href="listar.php" class="btn btn-secondary">Cancelar</a>
</form>
</div>

<?php include '../includes_footer.php'; ?>
