<?php
require_once '../config/database.php';
$pdo = getConnection();
$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("DELETE FROM salas WHERE id = ?");
$stmt->execute([$id]);

header("Location: listar.php?msg=Sala excluída com sucesso!");
exit;
