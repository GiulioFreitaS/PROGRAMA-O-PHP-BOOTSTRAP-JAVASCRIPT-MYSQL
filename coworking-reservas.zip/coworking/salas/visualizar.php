<?php
require_once '../config/database.php';
$pdo = getConnection();
$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM salas WHERE id = ?");
$stmt->execute([$id]);
$sala = $stmt->fetch();

if (!$sala) {
    header("Location: listar.php?msg=Sala não encontrada.");
    exit;
}

$stmtH = $pdo->prepare("SELECT * FROM horarios_disponiveis WHERE sala_id = ? ORDER BY FIELD(dia_semana,'Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'), hora_inicio");
$stmtH->execute([$id]);
$horarios = $stmtH->fetchAll();

$stmtR = $pdo->prepare("SELECT * FROM reservas WHERE sala_id = ? ORDER BY data_reserva DESC, hora_inicio DESC LIMIT 10");
$stmtR->execute([$id]);
$reservas = $stmtR->fetchAll();

include '../includes_header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="fw-bold"><i class="bi bi-door-open"></i> <?= htmlspecialchars($sala['nome']) ?></h3>
    <a href="listar.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left"></i> Voltar</a>
</div>

<div class="card card-stat p-4 mb-4">
    <p><strong>Descrição:</strong> <?= nl2br(htmlspecialchars($sala['descricao'])) ?: '<span class="text-muted">-</span>' ?></p>
    <p><strong>Capacidade:</strong> <?= $sala['capacidade'] ?> pessoas</p>
    <p><strong>Localização:</strong> <?= htmlspecialchars($sala['localizacao']) ?: '<span class="text-muted">-</span>' ?></p>
    <p class="mb-0"><strong>Status:</strong> <span class="badge badge-<?= $sala['status'] ?>"><?= ucfirst($sala['status']) ?></span></p>
</div>

<div class="card card-stat p-4 mb-4">
    <h5 class="fw-bold"><i class="bi bi-clock"></i> Horários disponíveis</h5>
    <?php if (count($horarios) === 0): ?>
        <p class="text-muted mb-0">Nenhum horário cadastrado para esta sala.</p>
    <?php else: ?>
    <table class="table mb-0">
        <thead><tr><th>Dia</th><th>Início</th><th>Fim</th></tr></thead>
        <tbody>
        <?php foreach ($horarios as $h): ?>
            <tr><td><?= $h['dia_semana'] ?></td><td><?= substr($h['hora_inicio'],0,5) ?></td><td><?= substr($h['hora_fim'],0,5) ?></td></tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<div class="card card-stat p-4">
    <h5 class="fw-bold"><i class="bi bi-calendar-check"></i> Últimas reservas</h5>
    <?php if (count($reservas) === 0): ?>
        <p class="text-muted mb-0">Nenhuma reserva registrada para esta sala.</p>
    <?php else: ?>
    <table class="table mb-0">
        <thead><tr><th>Responsável</th><th>Data</th><th>Horário</th><th>Status</th></tr></thead>
        <tbody>
        <?php foreach ($reservas as $r): ?>
            <tr>
                <td><?= htmlspecialchars($r['nome_responsavel']) ?></td>
                <td><?= date('d/m/Y', strtotime($r['data_reserva'])) ?></td>
                <td><?= substr($r['hora_inicio'],0,5) ?> - <?= substr($r['hora_fim'],0,5) ?></td>
                <td><span class="badge badge-<?= $r['status'] ?>"><?= ucfirst($r['status']) ?></span></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<?php include '../includes_footer.php'; ?>
