<?php
require_once 'config/database.php';
$pdo = getConnection();

$totalSalas = $pdo->query("SELECT COUNT(*) FROM salas")->fetchColumn();
$totalHorarios = $pdo->query("SELECT COUNT(*) FROM horarios_disponiveis")->fetchColumn();
$totalReservas = $pdo->query("SELECT COUNT(*) FROM reservas WHERE status = 'confirmada'")->fetchColumn();

$proximasReservas = $pdo->query("
    SELECT r.*, s.nome AS sala_nome
    FROM reservas r
    JOIN salas s ON s.id = r.sala_id
    WHERE r.status = 'confirmada' AND r.data_reserva >= CURDATE()
    ORDER BY r.data_reserva ASC, r.hora_inicio ASC
    LIMIT 5
")->fetchAll();

include 'includes_header.php';
?>

<div class="pt-3">
    <h2 class="fw-bold mb-1"><i class="bi bi-building"></i> Espaço de Co-working</h2>
    <p class="text-muted">Painel de controle — reserva de salas de reunião</p>

    <div class="row g-3 my-2">
        <div class="col-md-4">
            <div class="card card-stat p-3">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-1">Salas cadastradas</h6>
                        <h3 class="fw-bold mb-0"><?= $totalSalas ?></h3>
                    </div>
                    <i class="bi bi-door-open fs-1 text-primary"></i>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-stat p-3">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-1">Horários disponíveis</h6>
                        <h3 class="fw-bold mb-0"><?= $totalHorarios ?></h3>
                    </div>
                    <i class="bi bi-clock-history fs-1 text-success"></i>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-stat p-3">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-1">Reservas confirmadas</h6>
                        <h3 class="fw-bold mb-0"><?= $totalReservas ?></h3>
                    </div>
                    <i class="bi bi-calendar-check fs-1 text-warning"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-4 g-3">
        <div class="col-md-4">
            <a href="salas/listar.php" class="btn btn-outline-primary w-100 py-3"><i class="bi bi-door-open"></i> Gerenciar Salas</a>
        </div>
        <div class="col-md-4">
            <a href="horarios/listar.php" class="btn btn-outline-success w-100 py-3"><i class="bi bi-clock"></i> Gerenciar Horários</a>
        </div>
        <div class="col-md-4">
            <a href="reservas/listar.php" class="btn btn-outline-warning w-100 py-3"><i class="bi bi-calendar-check"></i> Gerenciar Reservas</a>
        </div>
    </div>

    <div class="card card-stat mt-5 p-3">
        <h5 class="fw-bold mb-3"><i class="bi bi-calendar-event"></i> Próximas reservas</h5>
        <?php if (count($proximasReservas) === 0): ?>
            <p class="text-muted mb-0">Nenhuma reserva futura encontrada.</p>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th>Sala</th>
                        <th>Responsável</th>
                        <th>Data</th>
                        <th>Horário</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($proximasReservas as $r): ?>
                    <tr>
                        <td><?= htmlspecialchars($r['sala_nome']) ?></td>
                        <td><?= htmlspecialchars($r['nome_responsavel']) ?></td>
                        <td><?= date('d/m/Y', strtotime($r['data_reserva'])) ?></td>
                        <td><?= substr($r['hora_inicio'],0,5) ?> - <?= substr($r['hora_fim'],0,5) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes_footer.php'; ?>
