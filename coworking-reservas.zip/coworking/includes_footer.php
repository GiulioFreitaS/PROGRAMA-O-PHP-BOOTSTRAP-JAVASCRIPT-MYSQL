</div>
<footer class="bg-dark text-light text-center py-3 mt-5">
  <div class="container">
    <small>&copy; <?= date('Y') ?> Espaço de Co-working — Projeto Acadêmico (PHP + Bootstrap + JS + MySQL)</small>
  </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= isset($base) ? $base : '' ?>assets/js/validacao.js"></script>
</body>
</html>
